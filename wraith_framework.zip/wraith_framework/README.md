# Wraith Framework v1.0

A modular Python pentesting framework.

## Usage

```
python3 wraith.py
```

## Requirements

- Python 3.8+
- colorama: pip install colorama
- paramiko (for SSH scripts): pip install paramiko

## Structure

```
wraith_framework/
├── wraith.py               ← main framework, run this
└── scripts/
    ├── recon/              ← information gathering
    ├── exploit/            ← exploitation modules
    ├── network/            ← network-level tools
    ├── web/                ← web application tools
    └── bruteforce/         ← credential attacks
```

## Quick Start

```
wraith > show scripts
wraith > use recon/port_scanner
wraith > set IP 192.168.1.1
wraith > show options
wraith > run
```

## Commands

| Command              | Description                        |
|----------------------|------------------------------------|
| use <cat/script>     | Load a script                      |
| set <KEY> <value>    | Set an option                      |
| show scripts         | List all loaded scripts            |
| show options         | Show current script options        |
| show variables       | Show global IP/PORT                |
| show targets         | Show saved targets                 |
| show broken          | Show scripts that failed to load   |
| run                  | Execute the loaded script          |
| back                 | Unload current script              |
| target add/del/use   | Manage saved targets               |
| workspace <name>     | Switch workspace                   |
| reload               | Reload scripts from disk           |
| info                 | Detailed script info               |
| clear                | Clear screen                       |
| help                 | Show all commands                  |

## Adding Your Own Scripts

Drop a .py file into any scripts/ subfolder with this structure:

```python
NAME        = "My Script"
DESCRIPTION = "What it does"
AUTHOR      = "You"
VERSION     = "1.0"
NOTES       = "Optional notes"

OPTIONS = {
    "IP":      {"description": "Target IP",    "required": True,  "default": None},
    "PORT":    {"description": "Target port",  "required": True,  "default": "80"},
    "TIMEOUT": {"description": "Timeout (s)",  "required": False, "default": "5"},
}

def run(opts):
    ip   = opts.get("IP")
    port = int(opts.get("PORT"))
    # your code here
```

Then run `reload` inside Wraith and it appears automatically.

## For Educational and Authorized Testing Only

Only use this framework against systems you own or have explicit written permission to test.
