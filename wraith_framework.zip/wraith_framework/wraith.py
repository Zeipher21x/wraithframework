import cmd
import os
import importlib.util
import inspect
import readline
import datetime
import json
import re

# ─────────────────────────────────────────────
#  COLOR HELPERS
# ─────────────────────────────────────────────
try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    R    = Fore.RED + Style.BRIGHT
    G    = Fore.GREEN + Style.BRIGHT
    Y    = Fore.YELLOW + Style.BRIGHT
    C    = Fore.CYAN + Style.BRIGHT
    M    = Fore.MAGENTA + Style.BRIGHT
    W    = Fore.WHITE + Style.BRIGHT
    DIM  = Style.DIM
    RESET= Style.RESET_ALL
    ANSI_LEN = True
except ImportError:
    R = G = Y = C = M = W = DIM = RESET = ""
    ANSI_LEN = False

def _pad(s, width):
    """Pad a string to visible width, accounting for invisible ANSI escape codes."""
    if not ANSI_LEN:
        return f"{s:<{width}}"
    visible_len = len(re.sub(r'\x1b\[[0-9;]*m', '', s))
    padding = max(0, width - visible_len)
    return s + " " * padding

def info(msg):    print(f"  {C}[*]{RESET} {msg}")
def success(msg): print(f"  {G}[+]{RESET} {msg}")
def error(msg):   print(f"  {R}[-]{RESET} {msg}")
def warn(msg):    print(f"  {Y}[!]{RESET} {msg}")

# ─────────────────────────────────────────────
#  CONSTANTS
# ─────────────────────────────────────────────
SCRIPTS_DIR    = "scripts"
LOG_DIR        = "logs"
HISTORY_FILE   = ".wraith_history"
WORKSPACE_FILE = "workspace.json"
VERSION        = "1.0"

# ─────────────────────────────────────────────
#  SCRIPT STANDARD
#
#  Every script must define:
#    NAME, DESCRIPTION, AUTHOR, VERSION
#    OPTIONS = { "KEY": {"description": "...", "required": True/False, "default": None} }
#    def run(opts): ...   ← opts is a dict
#
#  Optional:
#    NOTES = "..."
#
#  Example OPTIONS:
#    OPTIONS = {
#        "IP":       {"description": "Target IP address",  "required": True,  "default": None},
#        "PORT":     {"description": "Target port",        "required": True,  "default": "80"},
#        "WORDLIST": {"description": "Path to wordlist",   "required": True,  "default": None},
#        "THREADS":  {"description": "Number of threads",  "required": False, "default": "10"},
#        "TIMEOUT":  {"description": "Connection timeout", "required": False, "default": "5"},
#    }
# ─────────────────────────────────────────────

REQUIRED_ATTRS = ["NAME", "DESCRIPTION", "AUTHOR", "VERSION", "OPTIONS"]

def validate_script(module, path):
    """Returns (ok, list_of_issues). Checks all required attrs and run() signature."""
    issues = []
    for attr in REQUIRED_ATTRS:
        if not hasattr(module, attr):
            issues.append(f"missing attribute '{attr}'")
    if not hasattr(module, "run"):
        issues.append("missing run(opts) function")
    else:
        # FIX: correct signature check — run() must have at least one param named 'opts'
        sig = inspect.signature(module.run)
        if "opts" not in sig.parameters:
            issues.append("run() must accept an 'opts' dict parameter — def run(opts):")
    return len(issues) == 0, issues

def _sanitize_name(name):
    """Strip characters unsafe for filenames/paths. FIX: prevent path traversal."""
    return re.sub(r'[^a-zA-Z0-9_\-]', '_', name)

# ─────────────────────────────────────────────
#  SCRIPT LOADER
# ─────────────────────────────────────────────
def load_script_from_path(full_path, label):
    """Load and validate a single script. Returns (module|None, list_of_errors)."""
    try:
        spec   = importlib.util.spec_from_file_location(label, full_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        ok, issues = validate_script(module, full_path)
        if not ok:
            return None, issues
        return module, []
    except SyntaxError as e:
        return None, [f"SyntaxError on line {e.lineno}: {e.msg}"]
    except Exception as e:
        return None, [str(e)]

def discover_scripts():
    """
    Walk SCRIPTS_DIR. Returns:
      loaded = { category: [(script_path, module), ...] }
      broken = [(script_path, [issues]), ...]
    FIX: use context managers for scandir to avoid resource leaks.
    """
    loaded = {}
    broken = []

    if not os.path.exists(SCRIPTS_DIR):
        return loaded, broken

    try:
        # FIX: wrap scandir in list() to consume iterator before context closes
        top_entries = sorted(os.scandir(SCRIPTS_DIR), key=lambda e: e.name)
    except PermissionError as e:
        return loaded, broken

    for entry in top_entries:
        if entry.is_dir():
            category = entry.name
            loaded[category] = []
            try:
                sub_entries = sorted(os.scandir(entry.path), key=lambda e: e.name)
            except PermissionError:
                continue
            for f in sub_entries:
                if f.name.endswith(".py") and not f.name.startswith("_"):
                    script_name = f.name[:-3]
                    script_path = f"{category}/{script_name}"
                    module, issues = load_script_from_path(f.path, script_name)
                    if module:
                        loaded[category].append((script_path, module))
                    else:
                        broken.append((script_path, issues))
            # Remove empty categories
            if not loaded[category]:
                del loaded[category]
        elif entry.is_file() and entry.name.endswith(".py") and not entry.name.startswith("_"):
            category = "misc"
            if category not in loaded:
                loaded[category] = []
            script_name = entry.name[:-3]
            module, issues = load_script_from_path(entry.path, script_name)
            if module:
                loaded[category].append((script_name, module))
            else:
                broken.append((script_name, issues))

    return loaded, broken

def all_script_paths(scripts_dict):
    paths = []
    for cat_scripts in scripts_dict.values():
        for path, _ in cat_scripts:
            paths.append(path)
    return paths

def get_script(scripts_dict, path):
    if not path:
        return None
    for cat_scripts in scripts_dict.values():
        for p, m in cat_scripts:
            if p == path:
                return m
    return None

def _validate_port(port_str):
    """FIX: validate port is integer 1-65535. Returns (int|None, error_str|None)."""
    try:
        p = int(port_str)
        if not (1 <= p <= 65535):
            return None, f"Port must be between 1 and 65535, got {p}"
        return p, None
    except (ValueError, TypeError):
        return None, f"Invalid port '{port_str}' — must be a number"

# ─────────────────────────────────────────────
#  LOGGER
# ─────────────────────────────────────────────
class Logger:
    def __init__(self, workspace):
        os.makedirs(LOG_DIR, exist_ok=True)
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        # FIX: sanitize workspace name to prevent path traversal in log filename
        safe_name = _sanitize_name(workspace)
        self.path = os.path.join(LOG_DIR, f"{safe_name}_{ts}.log")
        self._log(f"Wraith Framework v{VERSION} — Session started")

    def _log(self, msg):
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        try:
            with open(self.path, "a") as f:
                f.write(f"[{ts}] {msg}\n")
        except OSError:
            pass  # don't crash the framework if logging fails

    def cmd(self, line):   self._log(f"CMD >> {line}")
    def result(self, msg): self._log(f"OUT >> {msg}")
    def event(self, msg):  self._log(f"EVT >> {msg}")

# ─────────────────────────────────────────────
#  WORKSPACE
# ─────────────────────────────────────────────
class Workspace:
    def __init__(self):
        self.name    = "default"
        self.targets = {}
        self._load()

    def _load(self):
        if os.path.exists(WORKSPACE_FILE):
            try:
                # FIX: use context manager instead of open() without close
                with open(WORKSPACE_FILE, "r") as f:
                    data = json.load(f)
                self.name    = data.get("name", "default")
                self.targets = data.get("targets", {})
            except (json.JSONDecodeError, OSError):
                warn(f"Could not load workspace file '{WORKSPACE_FILE}' — starting fresh.")

    def save(self):
        try:
            with open(WORKSPACE_FILE, "w") as f:
                json.dump({"name": self.name, "targets": self.targets}, f, indent=2)
        except OSError as e:
            error(f"Could not save workspace: {e}")

    def add_target(self, name, ip, port=None):
        self.targets[name] = {"ip": ip, "port": port}
        self.save()

    def remove_target(self, name):
        if name in self.targets:
            del self.targets[name]
            self.save()
            return True
        return False

# ─────────────────────────────────────────────
#  FRAMEWORK
# ─────────────────────────────────────────────
class Wraith(cmd.Cmd):

    def _build_prompt(self):
        ws  = f"{DIM}[{self.workspace.name}]{RESET}"
        ip  = f" {G}{self.ip}{RESET}" if self.ip else f" {DIM}no-target{RESET}"
        scr = f" {M}({self.script.split('/')[-1]}){RESET}" if self.script else ""
        return f"\n{ws}{ip}{scr}\n{R}wraith{RESET} {W}>{RESET} "

    def _refresh_prompt(self):
        self.prompt = self._build_prompt()

    # ── INIT ──────────────────────────────────
    def __init__(self):
        super().__init__()
        self.workspace      = Workspace()
        self._scripts       = {}
        self._broken        = []
        self.script         = None
        self.script_module  = None
        self.script_opts    = {}
        self.ip             = None
        self.port           = None
        self.logger         = Logger(self.workspace.name)
        self._refresh_prompt()
        self._load_history()
        self._do_discover(silent=False)
        self._print_banner()

    def _do_discover(self, silent=False):
        self._scripts, self._broken = discover_scripts()
        total       = sum(len(v) for v in self._scripts.values())
        broken_count = len(self._broken)
        if not silent:
            success(f"{G}{total}{RESET} script(s) loaded across {G}{len(self._scripts)}{RESET} category(s)")
            if broken_count:
                warn(f"{R}{broken_count}{RESET} broken script(s) — type {Y}show broken{RESET} for details")
        return total, broken_count

    def _print_banner(self):
        print(f"""
{R}  ██╗    ██╗██████╗  █████╗ ██╗████████╗██╗  ██╗{RESET}
{R}  ██║    ██║██╔══██╗██╔══██╗██║╚══██╔══╝██║  ██║{RESET}
{R}  ██║ █╗ ██║██████╔╝███████║██║   ██║   ███████║{RESET}
{R}  ██║███╗██║██╔══██╗██╔══██║██║   ██║   ██╔══██║{RESET}
{R}  ╚███╔███╔╝██║  ██║██║  ██║██║   ██║   ██║  ██║{RESET}
{R}   ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝   ╚═╝   ╚═╝  ╚═╝{RESET}

  {DIM}v{VERSION}  |  workspace: {self.workspace.name}  |  log: {self.logger.path}{RESET}
""")
        info(f"Type {Y}help{RESET} for commands  |  {Y}show scripts{RESET} to list modules")
        print()

    # ── HISTORY ───────────────────────────────
    def _load_history(self):
        try:
            if os.path.exists(HISTORY_FILE):
                readline.read_history_file(HISTORY_FILE)
            readline.set_history_length(500)
        except Exception:
            pass

    def _save_history(self):
        try:
            readline.write_history_file(HISTORY_FILE)
        except Exception:
            pass

    # ── TAB COMPLETION ────────────────────────
    def completenames(self, text, *ignored):
        cmds = [c[3:] for c in dir(self) if c.startswith("do_")]
        return [c for c in cmds if c.startswith(text)]

    def complete_use(self, text, line, begidx, endidx):
        return [p for p in all_script_paths(self._scripts) if p.startswith(text)]

    def complete_set(self, text, line, begidx, endidx):
        parts = line.split()
        # FIX: correct condition — show keys when: only 'set' typed with trailing space,
        # OR 'set' + partial key typed (no trailing space)
        # Previously: len(parts) <= 2 and not line.endswith(" ") missed the 'set ' case
        is_completing_key = (
            (len(parts) == 1 and line.endswith(" ")) or      # 'set <TAB>'
            (len(parts) == 2 and not line.endswith(" "))     # 'set IP<TAB>'
        )
        if is_completing_key:
            # FIX: deduplicate — use set() so IP/PORT don't appear twice
            keys = {"IP", "PORT"}
            if self.script_module and hasattr(self.script_module, "OPTIONS"):
                keys.update(self.script_module.OPTIONS.keys())
            return [o for o in sorted(keys) if o.startswith(text.upper())]
        # completing script path value after 'set SCRIPT '
        if len(parts) >= 2 and parts[1].upper() == "SCRIPT":
            return [p for p in all_script_paths(self._scripts) if p.startswith(text)]
        return []

    def complete_show(self, text, line, begidx, endidx):
        opts = ["scripts", "variables", "options", "targets", "broken"]
        return [o for o in opts if o.startswith(text)]

    def complete_target(self, text, line, begidx, endidx):
        parts = line.split()
        subcmds = ["add", "del", "use", "list"]
        if (len(parts) == 1 and line.endswith(" ")) or (len(parts) == 2 and not line.endswith(" ")):
            return [s for s in subcmds if s.startswith(text)]
        if len(parts) >= 2 and parts[1] in ("del", "use"):
            return [t for t in self.workspace.targets if t.startswith(text)]
        return []

    # ── PRECMD ────────────────────────────────
    def precmd(self, line):
        if line.strip():
            self.logger.cmd(line)
        return line

    def emptyline(self):
        pass

    def default(self, line):
        error(f"Unknown command '{line}'. Type {Y}help{RESET} for commands.")

    # ── SET ───────────────────────────────────
    def do_set(self, arg):
        "Set an option: set <KEY> <value>"
        parts = arg.split(None, 1)
        if len(parts) < 2:
            error("Usage: set <KEY> <value>")
            return
        key, value = parts[0].upper(), parts[1].strip()

        if not value:
            error(f"Value cannot be empty.")
            return

        # Special: load a script
        if key == "SCRIPT":
            self._load_script_by_path(value)
            return

        # Global IP/PORT — also sync into active script opts
        if key == "IP":
            self.ip = value
            if self.script_module and "IP" in self.script_opts:
                self.script_opts["IP"] = value
            success(f"IP => {Y}{value}{RESET}")
            self._refresh_prompt()
            return

        if key == "PORT":
            # FIX: validate port before accepting
            port_int, err = _validate_port(value)
            if err:
                error(err)
                return
            self.port = value
            if self.script_module and "PORT" in self.script_opts:
                self.script_opts["PORT"] = value
            success(f"PORT => {Y}{value}{RESET}")
            return

        # Script-level option
        if self.script_module and hasattr(self.script_module, "OPTIONS"):
            if key in self.script_module.OPTIONS:
                self.script_opts[key] = value
                if key == "IP":
                    self.ip = value
                    self._refresh_prompt()
                if key == "PORT":
                    port_int, err = _validate_port(value)
                    if err:
                        error(err)
                        return
                    self.port = value
                success(f"{key} => {Y}{value}{RESET}")
            else:
                error(f"Unknown option '{key}' for this script.")
                info(f"Use {Y}show options{RESET} to see available options.")
        else:
            error(f"Unknown option '{key}'. Load a script first, or use IP / PORT.")

    def _load_script_by_path(self, path):
        if not path:
            error("No script path provided.")
            return
        module = get_script(self._scripts, path)
        if module is None:
            error(f"Script '{path}' not found or failed to load.")
            info(f"Use {Y}show scripts{RESET} to see available modules.")
            return
        self.script        = path
        self.script_module = module

        # Build opts, seeding IP/PORT globals into matching OPTIONS keys
        self.script_opts = {}
        if hasattr(module, "OPTIONS"):
            for k, meta in module.OPTIONS.items():
                if k == "IP" and self.ip:
                    self.script_opts[k] = self.ip
                elif k == "PORT" and self.port:
                    self.script_opts[k] = self.port
                else:
                    self.script_opts[k] = meta.get("default")

        self._refresh_prompt()
        success(f"Loaded {Y}{path}{RESET}")
        print()
        self._show_script_info()

    # ── USE ───────────────────────────────────
    def do_use(self, arg):
        "Load a script: use <category/script_name>"
        arg = arg.strip()
        if not arg:
            error("Usage: use <category/script_name>")
            return
        self._load_script_by_path(arg)

    # ── SHOW ──────────────────────────────────
    def do_show(self, arg):
        "show scripts | show options | show variables | show targets | show broken"
        arg = arg.strip().lower()

        if arg == "scripts":
            total = sum(len(v) for v in self._scripts.values())
            # FIX: handle empty scripts dir gracefully
            if total == 0:
                warn(f"No scripts loaded. Drop .py files into {Y}./{SCRIPTS_DIR}/<category>/{RESET} and run {Y}reload{RESET}")
                return
            print(f"\n  {W}Loaded Scripts{RESET} {DIM}({total} total){RESET}\n")
            for category, scripts in self._scripts.items():
                print(f"  {Y}[{category.upper()}]{RESET}")
                # FIX: use _pad() for ANSI-aware column alignment
                print(f"  {DIM}{'Path':<35} {'Name':<22} Description{RESET}")
                print(f"  {DIM}{'-'*35} {'-'*22} {'-'*35}{RESET}")
                for path, module in scripts:
                    name    = getattr(module, 'NAME', path.split('/')[-1])
                    desc    = getattr(module, 'DESCRIPTION', '')
                    opts    = getattr(module, 'OPTIONS', {})
                    tags    = []
                    if "WORDLIST" in opts: tags.append("wordlist")
                    if "THREADS"  in opts: tags.append("threads")
                    tag_str = f" {DIM}[{', '.join(tags)}]{RESET}" if tags else ""
                    col1    = _pad(f"  {G}{path}{RESET}", 37)
                    print(f"{col1} {name:<22} {DIM}{desc}{RESET}{tag_str}")
                print()
            if self._broken:
                warn(f"{len(self._broken)} broken script(s) — type {Y}show broken{RESET}")

        elif arg == "options":
            if not self.script_module:
                error("No script loaded. Use: use <category/script>")
            else:
                self._show_script_info()

        elif arg == "variables":
            print()
            print(f"  {W}Global Variables:{RESET}")
            ip_val   = f"{G}{self.ip}{RESET}"   if self.ip   else f"{DIM}not set{RESET}"
            port_val = f"{G}{self.port}{RESET}"  if self.port else f"{DIM}not set{RESET}"
            print(f"    {C}IP  {RESET}  = {ip_val}")
            print(f"    {C}PORT{RESET}  = {port_val}")
            print()

        elif arg == "targets":
            self._show_targets()

        elif arg == "broken":
            self._show_broken()

        else:
            error("Usage: show <scripts|options|variables|targets|broken>")

    # ── INFO ──────────────────────────────────
    def do_info(self, arg):
        "Detailed info about the loaded script"
        if not self.script_module:
            error("No script loaded.")
        else:
            self._show_script_info(detailed=True)

    # ── RUN ───────────────────────────────────
    def do_run(self, arg):
        "Run the loaded script"
        if not self.script_module:
            error("No script loaded. Use: use <category/script>")
            return

        # Validate all required options
        missing = []
        if hasattr(self.script_module, "OPTIONS"):
            for key, meta in self.script_module.OPTIONS.items():
                val = self.script_opts.get(key)
                if meta.get("required", True) and not val:
                    missing.append((key, meta.get("description", "")))

        if missing:
            error("Cannot run — required options not set:\n")
            for k, desc in missing:
                print(f"    {_pad(R+k+RESET, 25)} {DIM}{desc}{RESET}")
            print(f"\n  Use {Y}set <KEY> <value>{RESET} to configure.\n")
            return

        # Validate port values if present
        if self.script_opts.get("PORT"):
            _, err = _validate_port(self.script_opts["PORT"])
            if err:
                error(f"Invalid PORT: {err}")
                return

        # Validate file path options exist on disk
        file_keys = ("WORDLIST", "FILE", "KEYFILE")
        for key in file_keys:
            val = self.script_opts.get(key)
            if val and not os.path.isfile(val):
                error(f"{key} file not found: {val}")
                return

        ts = datetime.datetime.now().strftime("%H:%M:%S")
        target_ip   = self.script_opts.get("IP", self.ip)
        target_port = self.script_opts.get("PORT", self.port)

        print()
        print(f"  {DIM}{'─'*58}{RESET}")
        info(f"Module  : {Y}{self.script}{RESET}")
        info(f"Target  : {G}{target_ip}{RESET}" +
             (f":{G}{target_port}{RESET}" if target_port else ""))
        info(f"Started : {DIM}{ts}{RESET}")
        print(f"  {DIM}{'─'*58}{RESET}\n")

        self.logger.event(f"RUN {self.script} opts={self.script_opts}")

        # FIX: catch KeyboardInterrupt cleanly so Ctrl+C doesn't crash the framework
        try:
            self.script_module.run(self.script_opts)
        except KeyboardInterrupt:
            print()
            warn("Script interrupted by user.")
            self.logger.event(f"INTERRUPTED {self.script}")
        except Exception as e:
            error(f"Script crashed: {e}")
            self.logger.event(f"CRASH {self.script}: {e}")

        end_ts = datetime.datetime.now().strftime("%H:%M:%S")
        print(f"\n  {DIM}{'─'*58}{RESET}")
        info(f"Complete : {DIM}{end_ts}{RESET}")
        print(f"  {DIM}{'─'*58}{RESET}\n")

    # ── RELOAD ────────────────────────────────
    def do_reload(self, arg):
        "Reload all scripts from disk"
        info("Scanning scripts directory...")
        self._do_discover(silent=False)
        if self.script:
            new_module = get_script(self._scripts, self.script)
            if new_module:
                self.script_module = new_module
                success(f"Active script {Y}{self.script}{RESET} reloaded.")
            else:
                warn(f"Active script {Y}{self.script}{RESET} no longer loads — unloading.")
                self.script        = None
                self.script_module = None
                self.script_opts   = {}
                self._refresh_prompt()

    # ── TARGET MANAGEMENT ─────────────────────
    def do_target(self, arg):
        "target add <n> <ip> [port] | target del <n> | target use <n> | target list"
        parts = arg.strip().split()
        if not parts:
            error("Usage: target <add|del|use|list>")
            return
        sub = parts[0].lower()

        if sub == "list":
            self._show_targets()

        elif sub == "add":
            if len(parts) < 3:
                error("Usage: target add <n> <ip> [port]")
                return
            name = parts[1]
            ip   = parts[2]
            port = None
            if len(parts) > 3:
                # FIX: validate port on target add
                port_int, err = _validate_port(parts[3])
                if err:
                    error(err)
                    return
                port = parts[3]
            self.workspace.add_target(name, ip, port)
            success(f"Target {Y}{name}{RESET} saved — {G}{ip}{RESET}" + (f":{G}{port}{RESET}" if port else ""))
            self.logger.event(f"TARGET ADD {name} {ip}:{port}")

        elif sub == "del":
            if len(parts) < 2:
                error("Usage: target del <n>")
                return
            name = parts[1]
            if self.workspace.remove_target(name):
                success(f"Target '{name}' removed.")
                # FIX: clear active IP if deleted target was the active one
                if self.ip and self.workspace.targets.get(name, {}).get("ip") == self.ip:
                    self.ip   = None
                    self.port = None
                    self._refresh_prompt()
            else:
                error(f"Target '{name}' not found.")

        elif sub == "use":
            if len(parts) < 2:
                error("Usage: target use <n>")
                return
            name = parts[1]
            t = self.workspace.targets.get(name)
            if not t:
                error(f"Target '{name}' not found.")
                return
            self.ip   = t["ip"]
            self.port = t.get("port")
            if self.script_module and "IP" in self.script_opts:
                self.script_opts["IP"] = self.ip
            if self.script_module and self.port and "PORT" in self.script_opts:
                self.script_opts["PORT"] = self.port
            self._refresh_prompt()
            success(f"Active target: {Y}{name}{RESET} — {G}{self.ip}{RESET}" +
                    (f":{G}{self.port}{RESET}" if self.port else ""))
        else:
            error(f"Unknown subcommand '{sub}'. Use add, del, use, or list.")

    def _show_targets(self):
        targets = self.workspace.targets
        if not targets:
            warn("No saved targets. Use: target add <n> <ip> [port]")
            return
        print(f"\n  {W}Targets — workspace: {self.workspace.name}{RESET}\n")
        print(f"  {DIM}{'Name':<20} {'IP':<18} {'Port':<8}{RESET}")
        print(f"  {DIM}{'-'*20} {'-'*18} {'-'*8}{RESET}")
        for name, t in targets.items():
            active = f" {G}← active{RESET}" if t["ip"] == self.ip else ""
            print(f"  {_pad(Y+name+RESET, 22)} {t['ip']:<18} {t.get('port') or 'N/A':<8}{active}")
        print()

    # ── WORKSPACE ─────────────────────────────
    def do_workspace(self, arg):
        "Switch workspace: workspace <n>"
        arg = arg.strip()
        if not arg:
            info(f"Current workspace: {Y}{self.workspace.name}{RESET}")
            return
        # FIX: sanitize workspace name
        safe = _sanitize_name(arg)
        if safe != arg:
            warn(f"Workspace name sanitized to '{safe}'")
        self.workspace.name = safe
        self.workspace.save()
        self.logger = Logger(safe)
        self._refresh_prompt()
        success(f"Workspace: {Y}{safe}{RESET}")

    # ── BACK ──────────────────────────────────
    def do_back(self, arg):
        "Unload current script"
        if not self.script:
            info("No script loaded.")
            return
        self.script        = None
        self.script_module = None
        self.script_opts   = {}
        self._refresh_prompt()
        info("Script unloaded.")

    # ── CLEAR ─────────────────────────────────
    def do_clear(self, arg):
        "Clear the screen"
        os.system("clear")

    # ── EXIT ──────────────────────────────────
    def do_exit(self, arg):
        "Exit Wraith"
        self._save_history()
        self.logger.event("Session ended")
        print(f"\n  {DIM}Wraith fades into the darkness...{RESET}\n")
        return True

    def do_quit(self, arg):
        "Exit Wraith"
        return self.do_exit(arg)

    # ── HELPERS ───────────────────────────────
    def _show_script_info(self, detailed=False):
        m = self.script_module
        print()
        print(f"  {DIM}{'─'*58}{RESET}")
        print(f"  {W}{'Module':<14}{RESET}{Y}{self.script}{RESET}")
        print(f"  {W}{'Name':<14}{RESET}{getattr(m, 'NAME', 'N/A')}")
        print(f"  {W}{'Description':<14}{RESET}{DIM}{getattr(m, 'DESCRIPTION', 'N/A')}{RESET}")
        print(f"  {W}{'Author':<14}{RESET}{getattr(m, 'AUTHOR', 'N/A')}")
        print(f"  {W}{'Version':<14}{RESET}{getattr(m, 'VERSION', 'N/A')}")
        if detailed and hasattr(m, "NOTES"):
            print(f"  {W}{'Notes':<14}{RESET}{DIM}{m.NOTES}{RESET}")
        print(f"  {DIM}{'─'*58}{RESET}")
        print(f"\n  {W}Options:{RESET}\n")

        if hasattr(m, "OPTIONS"):
            # Header
            h1 = _pad(f"  {DIM}Key{RESET}", 22)
            h2 = f"{'Value':<28}"
            h3 = f"{'Req':<6}"
            print(f"  {DIM}  {'Key':<18} {'Value':<28} {'Req':<6} Description{RESET}")
            print(f"  {DIM}  {'-'*18} {'-'*28} {'-'*6} {'-'*30}{RESET}")
            for key, meta in m.OPTIONS.items():
                val     = self.script_opts.get(key)
                req     = meta.get("required", True)
                desc    = meta.get("description", "")
                default = meta.get("default")
                req_str = f"{R}yes{RESET}" if req else f"{DIM}no{RESET}"
                if val:
                    val_display = f"{G}{val}{RESET}"
                elif req:
                    val_display = f"{R}not set{RESET}"
                else:
                    val_display = f"{DIM}{default if default is not None else 'not set'}{RESET}"
                # FIX: use _pad for ANSI-aware column alignment
                col_key = _pad(f"    {C}{key}{RESET}", 22)
                col_val = _pad(val_display, 28)
                col_req = _pad(req_str, 14)
                print(f"{col_key} {col_val} {col_req} {DIM}{desc}{RESET}")
        print()

    def _show_broken(self):
        if not self._broken:
            success("No broken scripts found.")
            return
        print(f"\n  {R}Broken Scripts ({len(self._broken)}){RESET}\n")
        for path, issues in self._broken:
            print(f"  {Y}{path}{RESET}")
            for issue in issues:
                print(f"    {R}✗{RESET} {DIM}{issue}{RESET}")
            print()


# ─────────────────────────────────────────────
#  ENTRY
# ─────────────────────────────────────────────
if __name__ == "__main__":
    for folder in ["scripts/recon", "scripts/exploit", "scripts/web", LOG_DIR]:
        os.makedirs(folder, exist_ok=True)
    try:
        Wraith().cmdloop()
    except KeyboardInterrupt:
        print(f"\n\n  {DIM}Wraith fades into the darkness...{RESET}\n")
