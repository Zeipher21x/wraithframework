import socket
import re

NAME        = "WHOIS Lookup"
DESCRIPTION = "Queries WHOIS servers for domain registration and IP ownership info"
AUTHOR      = "Wraith"
VERSION     = "2.0"
NOTES       = "Pure stdlib implementation. Follows referral chains automatically."

OPTIONS = {
    "IP":      {"description": "Domain or IP to query",    "required": True,  "default": None},
    "TIMEOUT": {"description": "Query timeout (seconds)",  "required": False, "default": "5"},
}

WHOIS_SERVERS = {
    "com": "whois.verisign-grs.com",
    "net": "whois.verisign-grs.com",
    "org": "whois.pir.org",
    "io":  "whois.nic.io",
    "co":  "whois.nic.co",
    "uk":  "whois.nic.uk",
    "de":  "whois.denic.de",
    "ru":  "whois.tcinet.ru",
    "cn":  "whois.cnnic.cn",
    "au":  "whois.auda.org.au",
    "fr":  "whois.nic.fr",
    "_ip": "whois.arin.net",
    "_default": "whois.iana.org",
}

INTERESTING_FIELDS = [
    "domain name", "registrar", "creation date", "updated date",
    "expiry date", "expiration date", "name server",
    "registrant", "registrant organization", "registrant country",
    "status", "dnssec", "netname", "org", "country",
    "cidr", "abuse-mailbox", "tech-c", "admin-c",
]

def whois_query(target, server, timeout):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((server, 43))
        s.send((target + "\r\n").encode())
        data = b""
        while True:
            chunk = s.recv(4096)
            if not chunk: break
            data += chunk
        s.close()
        return data.decode(errors="ignore")
    except Exception as e:
        return f"Error querying {server}: {e}"

def get_whois_server(target):
    is_ip = False
    try:
        socket.inet_aton(target)
        is_ip = True
    except socket.error:
        pass
    if is_ip:
        return WHOIS_SERVERS["_ip"]
    parts = target.lower().split(".")
    tld = parts[-1] if parts else ""
    return WHOIS_SERVERS.get(tld, WHOIS_SERVERS["_default"])

def find_referral(text):
    patterns = [
        r"whois:\s+(\S+)",
        r"Whois Server:\s+(\S+)",
        r"refer:\s+(\S+)",
        r"ReferralServer:\s+whois://(\S+)",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            return m.group(1).strip().rstrip("/")
    return None

def run(opts):
    target  = opts.get("IP", "").strip()
    timeout = float(opts.get("TIMEOUT") or 5)

    print(f"  \033[96m[*]\033[0m Looking up: {target}\n")

    server = get_whois_server(target)
    print(f"  \033[96m[*]\033[0m WHOIS server: {server}")

    raw = whois_query(target, server, timeout)

    # follow referral
    referral = find_referral(raw)
    if referral and referral != server:
        print(f"  \033[96m[*]\033[0m Following referral: {referral}")
        raw2 = whois_query(target, referral, timeout)
        if raw2 and "error" not in raw2.lower()[:20]:
            raw = raw2

    print()

    # parse and display interesting fields
    print(f"  \033[93m[WHOIS Data]\033[0m\n")
    seen_fields = set()
    lines = raw.splitlines()
    for line in lines:
        if ":" not in line or line.strip().startswith("%") or line.strip().startswith("#"):
            continue
        key, _, val = line.partition(":")
        key  = key.strip().lower()
        val  = val.strip()
        if not val or key in seen_fields:
            continue
        if any(f in key for f in INTERESTING_FIELDS):
            seen_fields.add(key)
            label = key.replace("-", " ").title()
            # flag important fields
            important = any(x in key for x in ["registrar","creation","expir","name server","cidr","netname","org","status"])
            marker = "\033[92m[+]\033[0m" if important else "\033[2m[ ]\033[0m"
            print(f"    {marker} {label:<30} {val}")

    # check expiry
    for line in lines:
        if any(x in line.lower() for x in ["expir", "expires"]) and ":" in line:
            val = line.split(":", 1)[1].strip()
            date_m = re.search(r"(\d{4}-\d{2}-\d{2})", val)
            if date_m:
                import datetime
                try:
                    exp = datetime.datetime.strptime(date_m.group(1), "%Y-%m-%d")
                    days = (exp - datetime.datetime.utcnow()).days
                    if days < 0:
                        print(f"\n  \033[91m[!]\033[0m Domain EXPIRED {abs(days)} days ago!")
                    elif days < 30:
                        print(f"\n  \033[93m[!]\033[0m Domain expires in {days} days")
                    else:
                        print(f"\n  \033[92m[+]\033[0m Domain expires in {days} days")
                except Exception:
                    pass
                break
    print()
