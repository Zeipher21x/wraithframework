import socket
import struct
import threading
import queue

NAME        = "DNS Recon"
DESCRIPTION = "Full DNS reconnaissance: A, MX, NS, TXT, CNAME, PTR, zone info, and subdomain enumeration"
AUTHOR      = "Wraith"
VERSION     = "2.0"
NOTES       = "Uses stdlib socket only. WORDLIST enables subdomain brute force."

OPTIONS = {
    "IP":        {"description": "Target domain or IP",                    "required": True,  "default": None},
    "WORDLIST":  {"description": "Path to subdomain wordlist (optional)",  "required": False, "default": None},
    "THREADS":   {"description": "Threads for subdomain brute force",      "required": False, "default": "30"},
    "TIMEOUT":   {"description": "DNS lookup timeout (seconds)",           "required": False, "default": "3"},
}

RECORD_TYPES = {
    1:   "A",
    2:   "NS",
    5:   "CNAME",
    15:  "MX",
    16:  "TXT",
    28:  "AAAA",
    255: "ANY",
}

def dns_query(domain, record_type=1, server="8.8.8.8", timeout=3):
    """Build and send a raw DNS query. Returns list of answer strings."""
    try:
        # Build DNS query packet
        tid  = 0x1337
        flags = 0x0100  # standard query, recursion desired
        qdcount = 1
        header = struct.pack(">HHHHHH", tid, flags, qdcount, 0, 0, 0)
        # encode QNAME
        qname = b""
        for label in domain.split("."):
            encoded = label.encode()
            qname += bytes([len(encoded)]) + encoded
        qname += b"\x00"
        qtype  = record_type
        qclass = 1  # IN
        question = qname + struct.pack(">HH", qtype, qclass)
        packet = header + question

        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(timeout)
        s.sendto(packet, (server, 53))
        response, _ = s.recvfrom(4096)
        s.close()

        return parse_dns_response(response, record_type)
    except Exception:
        return []

def decode_name(data, offset):
    """Decode a DNS name from a packet, following compression pointers."""
    labels = []
    visited = set()
    while offset < len(data):
        if offset in visited:
            break
        visited.add(offset)
        length = data[offset]
        if length == 0:
            offset += 1
            break
        elif (length & 0xC0) == 0xC0:
            # pointer
            if offset + 1 >= len(data):
                break
            ptr = ((length & 0x3F) << 8) | data[offset + 1]
            sub, _ = decode_name(data, ptr)
            labels.append(sub)
            offset += 2
            break
        else:
            offset += 1
            labels.append(data[offset:offset + length].decode(errors="ignore"))
            offset += length
    return ".".join(labels), offset

def parse_dns_response(data, qtype):
    """Parse DNS response and extract answers."""
    results = []
    try:
        ancount = struct.unpack(">H", data[6:8])[0]
        # skip header (12 bytes) + question section
        offset = 12
        # skip question
        while offset < len(data) and data[offset] != 0:
            if (data[offset] & 0xC0) == 0xC0:
                offset += 2
                break
            offset += data[offset] + 1
        else:
            offset += 1
        offset += 4  # skip QTYPE and QCLASS

        for _ in range(ancount):
            if offset >= len(data):
                break
            _, offset = decode_name(data, offset)
            if offset + 10 > len(data):
                break
            rtype, rclass, ttl, rdlen = struct.unpack(">HHIH", data[offset:offset + 10])
            offset += 10
            rdata = data[offset:offset + rdlen]
            offset += rdlen

            if rtype == 1 and len(rdata) == 4:  # A
                results.append(socket.inet_ntoa(rdata))
            elif rtype == 28 and len(rdata) == 16:  # AAAA
                results.append(socket.inet_ntop(socket.AF_INET6, rdata))
            elif rtype in (2, 5, 12):  # NS, CNAME, PTR
                name, _ = decode_name(data, offset - rdlen)
                results.append(name)
            elif rtype == 15:  # MX
                pref = struct.unpack(">H", rdata[:2])[0]
                name, _ = decode_name(data, offset - rdlen + 2)
                results.append(f"{pref} {name}")
            elif rtype == 16:  # TXT
                txt_parts = []
                i = 0
                while i < len(rdata):
                    l = rdata[i]; i += 1
                    txt_parts.append(rdata[i:i+l].decode(errors="ignore"))
                    i += l
                results.append("".join(txt_parts))
    except Exception:
        pass
    return results

def subdomain_worker(domain, wordlist_queue, found, lock, timeout):
    while True:
        try:
            word = wordlist_queue.get_nowait()
        except queue.Empty:
            break
        try:
            subdomain = f"{word}.{domain}"
            ips = dns_query(subdomain, record_type=1, timeout=timeout)
            if ips:
                with lock:
                    found.append((subdomain, ips))
        except Exception:
            pass
        finally:
            wordlist_queue.task_done()

def run(opts):
    target   = opts.get("IP", "").strip()
    wordlist = opts.get("WORDLIST")
    threads  = int(opts.get("THREADS") or 30)
    timeout  = float(opts.get("TIMEOUT") or 3)

    # determine if target is IP (PTR lookup) or domain (forward lookups)
    is_ip = False
    try:
        socket.inet_aton(target)
        is_ip = True
    except socket.error:
        pass

    print(f"  \033[96m[*]\033[0m Target  : {target}")
    print(f"  \033[96m[*]\033[0m Mode    : {'Reverse (PTR)' if is_ip else 'Forward (A/MX/NS/TXT)'}")
    print()

    if is_ip:
        # PTR lookup
        print(f"  \033[93m[PTR Record]\033[0m")
        try:
            hostname, aliases, _ = socket.gethostbyaddr(target)
            print(f"  \033[92m  [+]\033[0m {target} -> {hostname}")
            for a in aliases:
                print(f"  \033[92m  [+]\033[0m alias: {a}")
        except socket.herror:
            print(f"  \033[91m  [-]\033[0m No PTR record found")
        return

    # Forward DNS recon
    query_types = [
        (1,  "A"),
        (28, "AAAA"),
        (2,  "NS"),
        (15, "MX"),
        (16, "TXT"),
        (5,  "CNAME"),
    ]

    for qtype, label in query_types:
        results = dns_query(target, record_type=qtype, timeout=timeout)
        if results:
            print(f"  \033[93m[{label}]\033[0m")
            for r in results:
                print(f"  \033[92m  [+]\033[0m {r}")
            print()

    # Check for interesting TXT records
    txt_records = dns_query(target, record_type=16, timeout=timeout)
    spf = [r for r in txt_records if "v=spf" in r.lower()]
    dmarc_results = dns_query(f"_dmarc.{target}", record_type=16, timeout=timeout)
    dkim_results  = dns_query(f"default._domainkey.{target}", record_type=16, timeout=timeout)

    if spf or dmarc_results or dkim_results:
        print(f"  \033[93m[Email Security]\033[0m")
        for r in spf:
            print(f"  \033[92m  [SPF]\033[0m    {r}")
        for r in dmarc_results:
            print(f"  \033[92m  [DMARC]\033[0m  {r}")
        for r in dkim_results:
            print(f"  \033[92m  [DKIM]\033[0m   {r[:100]}")
        print()

    # Check zone transfer (AXFR) possibility
    print(f"  \033[93m[Zone Transfer Probe]\033[0m")
    ns_records = dns_query(target, record_type=2, timeout=timeout)
    if ns_records:
        for ns in ns_records[:3]:
            try:
                ns_ip = socket.gethostbyname(ns.rstrip("."))
                # attempt TCP connection on port 53 (AXFR requires TCP)
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(timeout)
                rc = s.connect_ex((ns_ip, 53))
                s.close()
                if rc == 0:
                    print(f"  \033[93m  [!]\033[0m NS {ns} ({ns_ip}) has TCP/53 open — zone transfer may be possible")
                else:
                    print(f"  \033[2m  [-] NS {ns} TCP/53 closed\033[0m")
            except Exception:
                pass
    else:
        print(f"  \033[2m  [-] No NS records to probe\033[0m")
    print()

    # Subdomain enumeration
    if wordlist:
        try:
            with open(wordlist) as f:
                words = [line.strip() for line in f if line.strip() and not line.startswith("#")]
        except Exception as e:
            print(f"  \033[91m[-]\033[0m Cannot read wordlist: {e}")
            return

        print(f"  \033[93m[Subdomain Brute Force]\033[0m")
        print(f"  \033[96m  [*]\033[0m Testing {len(words)} subdomains with {threads} threads...\n")

        wq     = queue.Queue()
        found  = []
        lock   = threading.Lock()
        for w in words:
            wq.put(w)

        workers = []
        for _ in range(min(threads, len(words))):
            t = threading.Thread(target=subdomain_worker, args=(target, wq, found, lock, timeout), daemon=True)
            t.start()
            workers.append(t)

        import time
        total = len(words)
        while not wq.empty():
            done = total - wq.qsize()
            print(f"  \033[2m  Progress: {done}/{total}\033[0m", end="\r")
            time.sleep(0.2)

        for t in workers:
            t.join()
        print(" " * 50, end="\r")

        if found:
            found.sort(key=lambda x: x[0])
            print(f"  \033[92m[+]\033[0m {len(found)} subdomain(s) found:\n")
            for sub, ips in found:
                print(f"  \033[92m  [+]\033[0m {sub:<45} {', '.join(ips)}")
        else:
            print(f"  \033[91m  [-]\033[0m No subdomains found")
        print()
