import socket

NAME        = "Banner Grabber"
DESCRIPTION = "Grabs the service banner from a target IP and PORT"
AUTHOR      = "You"
VERSION     = "1.0"

OPTIONS = {
    "IP":      {"description": "Target IP address",      "required": True,  "default": None},
    "PORT":    {"description": "Target port",            "required": True,  "default": None},
    "TIMEOUT": {"description": "Connection timeout (s)", "required": False, "default": "3"},
}

def run(opts):
    ip      = opts.get("IP")
    port    = int(opts.get("PORT"))
    timeout = float(opts.get("TIMEOUT") or 3)
    print(f"  Grabbing banner from {ip}:{port}...\n")
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((ip, port))
        s.send(b"HEAD / HTTP/1.0\r\n\r\n")
        banner = s.recv(1024).decode(errors="ignore").strip()
        s.close()
        if banner:
            print(f"  \033[92m[+]\033[0m Banner:\n")
            for line in banner.splitlines():
                print(f"      {line}")
        else:
            print("  [-] No banner received.")
    except ConnectionRefusedError:
        print(f"  [-] Connection refused on {ip}:{port}")
    except socket.timeout:
        print("  [-] Timed out.")
    except Exception as e:
        print(f"  [!] {e}")
    print()
