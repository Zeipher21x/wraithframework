import socket
import threading
import queue
import time
from datetime import datetime

NAME        = "TCP Port Scanner"
DESCRIPTION = "Threaded TCP scanner with service detection and banner grabbing"
AUTHOR      = "Wraith"
VERSION     = "2.0"
NOTES       = "Scans port ranges using a thread pool. Grabs banners on open ports."

OPTIONS = {
    "IP":      {"description": "Target IP or hostname",             "required": True,  "default": None},
    "PORTS":   {"description": "Range: 1-1024 or list: 80,443",    "required": False, "default": "1-1024"},
    "THREADS": {"description": "Concurrent threads (max 500)",      "required": False, "default": "100"},
    "TIMEOUT": {"description": "Socket timeout per port (seconds)", "required": False, "default": "1"},
    "BANNERS": {"description": "Grab banners on open ports",        "required": False, "default": "true"},
}

SERVICE_PROBES = {
    21: b"", 22: b"", 25: b"EHLO wraith\r\n",
    80: b"HEAD / HTTP/1.0\r\n\r\n",
    110: b"", 143: b"",
    443: b"HEAD / HTTP/1.0\r\n\r\n",
    3306: b"", 5432: b"", 6379: b"PING\r\n",
    8080: b"HEAD / HTTP/1.0\r\n\r\n",
    8443: b"HEAD / HTTP/1.0\r\n\r\n",
    9200: b"GET / HTTP/1.0\r\n\r\n",
}

def parse_ports(port_str):
    ports = []
    for part in port_str.split(","):
        part = part.strip()
        if "-" in part:
            try:
                s, e = part.split("-", 1)
                ports.extend(range(int(s), int(e) + 1))
            except ValueError:
                pass
        else:
            try:
                ports.append(int(part))
            except ValueError:
                pass
    return sorted(set(p for p in ports if 1 <= p <= 65535))

def grab_banner(ip, port, timeout):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((ip, port))
        probe = SERVICE_PROBES.get(port, b"")
        if probe:
            s.send(probe)
        banner = s.recv(1024).decode(errors="ignore").strip()
        s.close()
        for line in banner.splitlines():
            line = line.strip()
            if line:
                return line[:120]
    except Exception:
        pass
    return None

def scan_worker(ip, port_queue, results, lock, timeout, grab):
    while True:
        try:
            port = port_queue.get_nowait()
        except queue.Empty:
            break
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            rc = s.connect_ex((ip, port))
            s.close()
            if rc == 0:
                banner = grab_banner(ip, port, timeout) if grab else None
                try:
                    service = socket.getservbyport(port, "tcp")
                except OSError:
                    service = "unknown"
                with lock:
                    results.append((port, service, banner))
        except Exception:
            pass
        finally:
            port_queue.task_done()

def run(opts):
    ip       = opts.get("IP")
    port_str = opts.get("PORTS") or "1-1024"
    threads  = min(int(opts.get("THREADS") or 100), 500)
    timeout  = float(opts.get("TIMEOUT") or 1)
    grab     = (opts.get("BANNERS") or "true").lower() not in ("false", "0", "no")

    try:
        resolved = socket.gethostbyname(ip)
        if resolved != ip:
            print(f"  \033[96m[*]\033[0m Resolved {ip} -> {resolved}")
            ip = resolved
    except socket.gaierror as e:
        print(f"  \033[91m[-]\033[0m Cannot resolve '{opts.get('IP')}': {e}")
        return

    ports = parse_ports(port_str)
    if not ports:
        print(f"  \033[91m[-]\033[0m Invalid port specification: {port_str}")
        return

    print(f"  \033[96m[*]\033[0m Target  : {ip}")
    print(f"  \033[96m[*]\033[0m Ports   : {len(ports)} ({port_str})")
    print(f"  \033[96m[*]\033[0m Threads : {threads}  Timeout: {timeout}s  Banners: {'yes' if grab else 'no'}")
    print()

    start   = datetime.now()
    pq      = queue.Queue()
    results = []
    lock    = threading.Lock()

    for p in ports:
        pq.put(p)

    workers = []
    for _ in range(min(threads, len(ports))):
        t = threading.Thread(target=scan_worker, args=(ip, pq, results, lock, timeout, grab), daemon=True)
        t.start()
        workers.append(t)

    total = len(ports)
    while not pq.empty():
        done = total - pq.qsize()
        pct  = int((done / total) * 40)
        bar  = "\u2588" * pct + "\u2591" * (40 - pct)
        print(f"  \033[2m  [{bar}] {done}/{total}\033[0m", end="\r")
        time.sleep(0.15)

    for t in workers:
        t.join()
    print(" " * 70, end="\r")

    elapsed = (datetime.now() - start).total_seconds()
    results.sort(key=lambda x: x[0])

    if not results:
        print(f"  \033[91m[-]\033[0m No open ports found in {elapsed:.2f}s")
        return

    print(f"  \033[92m[+]\033[0m {len(results)} open port(s) in {elapsed:.2f}s\n")
    print(f"  \033[2m  {'PORT':<8} {'SERVICE':<16} BANNER\033[0m")
    print(f"  \033[2m  {'─'*8} {'─'*16} {'─'*55}\033[0m")
    for port, service, banner in results:
        b = f"  \033[2m{banner}\033[0m" if banner else ""
        print(f"  \033[92m  {port:<8}\033[0m \033[93m{service:<16}\033[0m{b}")
    print()
