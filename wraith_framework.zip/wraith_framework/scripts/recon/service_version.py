import socket
import ssl
import struct
import re

NAME        = "Service Version Detector"
DESCRIPTION = "Deep fingerprinting of services: HTTP, SSH, FTP, SMTP, MySQL, Redis, and more"
AUTHOR      = "Wraith"
VERSION     = "2.0"
NOTES       = "Sends protocol-aware probes and parses version strings from responses"

OPTIONS = {
    "IP":      {"description": "Target IP or hostname", "required": True,  "default": None},
    "PORT":    {"description": "Target port",           "required": True,  "default": None},
    "TIMEOUT": {"description": "Socket timeout (s)",    "required": False, "default": "5"},
    "SSL":     {"description": "Force SSL/TLS",         "required": False, "default": "auto"},
}

def recv_all(s, size=4096, timeout=2):
    s.settimeout(timeout)
    data = b""
    try:
        while True:
            chunk = s.recv(size)
            if not chunk:
                break
            data += chunk
            if len(data) >= size * 4:
                break
    except socket.timeout:
        pass
    return data

def probe_generic(ip, port, timeout, use_ssl):
    """Connect and read whatever the service sends first."""
    try:
        raw = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        raw.settimeout(timeout)
        raw.connect((ip, port))
        if use_ssl:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            s = ctx.wrap_socket(raw, server_hostname=ip)
        else:
            s = raw
        banner = recv_all(s, timeout=2).decode(errors="ignore").strip()
        s.close()
        return banner
    except Exception:
        return None

def probe_http(ip, port, timeout, use_ssl):
    results = {}
    try:
        raw = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        raw.settimeout(timeout)
        raw.connect((ip, port))
        if use_ssl:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            s = ctx.wrap_socket(raw, server_hostname=ip)
        else:
            s = raw
        req = f"HEAD / HTTP/1.1\r\nHost: {ip}\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n"
        s.send(req.encode())
        response = recv_all(s, timeout=3).decode(errors="ignore")
        s.close()
        # parse headers
        for line in response.splitlines():
            if ": " in line:
                k, v = line.split(": ", 1)
                results[k.strip().lower()] = v.strip()
        # also grab status line
        if response:
            results["_status"] = response.splitlines()[0].strip()
    except Exception as e:
        results["_error"] = str(e)
    return results

def probe_ssl_cert(ip, port, timeout):
    """Extract SSL certificate details."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with ctx.wrap_socket(socket.socket(), server_hostname=ip) as s:
            s.settimeout(timeout)
            s.connect((ip, port))
            cert = s.getpeercert()
            return cert
    except Exception:
        return None

def detect_service(port, banner):
    """Heuristic service detection from port + banner."""
    banner_lower = (banner or "").lower()
    if port == 22 or "ssh" in banner_lower:
        return "SSH"
    if port in (80, 8080, 8000) or "http" in banner_lower:
        return "HTTP"
    if port in (443, 8443):
        return "HTTPS"
    if port == 21 or banner_lower.startswith("220") and "ftp" in banner_lower:
        return "FTP"
    if port == 25 or (banner_lower.startswith("220") and "smtp" in banner_lower):
        return "SMTP"
    if port == 110 or banner_lower.startswith("+ok"):
        return "POP3"
    if port == 143 or "imap" in banner_lower:
        return "IMAP"
    if port == 3306 or (banner and len(banner) > 4 and banner[4] == "\n"):
        return "MySQL"
    if port == 5432:
        return "PostgreSQL"
    if port == 6379 or "+pong" in banner_lower:
        return "Redis"
    if port == 27017:
        return "MongoDB"
    if port == 9200 or '"cluster_name"' in banner_lower:
        return "Elasticsearch"
    if port == 3389:
        return "RDP"
    if port == 5900:
        return "VNC"
    return "Unknown"

def run(opts):
    ip      = opts.get("IP")
    port    = int(opts.get("PORT"))
    timeout = float(opts.get("TIMEOUT") or 5)
    ssl_opt = (opts.get("SSL") or "auto").lower()

    try:
        resolved = socket.gethostbyname(ip)
        if resolved != ip:
            print(f"  \033[96m[*]\033[0m Resolved {ip} -> {resolved}")
    except socket.gaierror as e:
        print(f"  \033[91m[-]\033[0m Cannot resolve: {e}")
        return

    print(f"  \033[96m[*]\033[0m Probing {ip}:{port} ...\n")

    # determine SSL
    use_ssl = ssl_opt == "true" or (ssl_opt == "auto" and port in (443, 8443, 465, 993, 995, 636))

    # --- generic banner ---
    banner = probe_generic(ip, port, timeout, use_ssl)
    service = detect_service(port, banner)

    print(f"  \033[93m[Service]\033[0m  {service}")
    if banner:
        for line in banner.splitlines()[:5]:
            if line.strip():
                print(f"  \033[92m[Banner]\033[0m   {line.strip()}")

    # --- HTTP specific ---
    if service in ("HTTP", "HTTPS") or port in (80, 443, 8080, 8443, 8000, 8888):
        print()
        print(f"  \033[93m[HTTP Headers]\033[0m")
        headers = probe_http(ip, port, timeout, use_ssl or port in (443, 8443))
        interesting = ["server", "x-powered-by", "x-aspnet-version", "x-generator",
                       "via", "x-frame-options", "strict-transport-security",
                       "content-security-policy", "_status", "set-cookie"]
        for h in interesting:
            if h in headers:
                label = h.lstrip("_").replace("-", " ").title()
                val   = headers[h]
                if h == "set-cookie":
                    val = val[:80] + "..." if len(val) > 80 else val
                marker = "\033[92m[+]\033[0m" if h in ("server", "x-powered-by", "x-aspnet-version", "_status") else "\033[2m[ ]\033[0m"
                print(f"    {marker} {label:<30} {val}")

    # --- SSL certificate ---
    if use_ssl or port in (443, 8443, 465, 993, 995):
        print()
        print(f"  \033[93m[SSL Certificate]\033[0m")
        cert = probe_ssl_cert(ip, port, timeout)
        if cert:
            subject = dict(x[0] for x in cert.get("subject", []))
            issuer  = dict(x[0] for x in cert.get("issuer", []))
            print(f"    \033[92m[+]\033[0m Subject CN   : {subject.get('commonName', 'N/A')}")
            print(f"    \033[92m[+]\033[0m Subject O    : {subject.get('organizationName', 'N/A')}")
            print(f"    \033[92m[+]\033[0m Issuer       : {issuer.get('organizationName', 'N/A')}")
            print(f"    \033[92m[+]\033[0m Expires      : {cert.get('notAfter', 'N/A')}")
            sans = cert.get("subjectAltName", [])
            if sans:
                san_list = [v for t, v in sans if t == "DNS"]
                print(f"    \033[92m[+]\033[0m SANs ({len(san_list)})     : {', '.join(san_list[:8])}")
        else:
            print(f"    \033[91m[-]\033[0m Could not retrieve certificate")

    # --- version extraction ---
    print()
    print(f"  \033[93m[Version Hints]\033[0m")
    version_patterns = [
        r"OpenSSH[_/][\d.]+",
        r"Apache[/ ][\d.]+",
        r"nginx[/ ][\d.]+",
        r"Microsoft-IIS[/ ][\d.]+",
        r"vsftpd [\d.]+",
        r"ProFTPD [\d.]+",
        r"Postfix",
        r"Exim [\d.]+",
        r"MySQL [\d.]+",
        r"MariaDB[\-/ ][\d.]+",
        r"Redis server v=[\d.]+",
        r"PHP[/ ][\d.]+",
        r"Python[/ ][\d.]+",
        r"OpenSSL[/ ][\d.]+",
    ]
    found_versions = []
    search_text = banner or ""
    for pat in version_patterns:
        m = re.search(pat, search_text, re.IGNORECASE)
        if m:
            found_versions.append(m.group(0))

    if found_versions:
        for v in found_versions:
            print(f"    \033[92m[+]\033[0m {v}")
    else:
        print(f"    \033[2m[-] No version strings detected in banner\033[0m")

    print()
