import socket

NAME        = "DNS Lookup"
DESCRIPTION = "Resolves hostnames and performs reverse DNS"
AUTHOR      = "You"
VERSION     = "1.0"

OPTIONS = {
    "IP": {"description": "Target IP or hostname to resolve", "required": True, "default": None},
}

def run(opts):
    ip = opts.get("IP")
    print(f"  Running DNS lookup on {ip}...\n")
    try:
        hostname, aliases, addresses = socket.gethostbyaddr(ip)
        print(f"  \033[92m[+]\033[0m Hostname  : {hostname}")
        if aliases:
            print(f"  \033[92m[+]\033[0m Aliases   : {', '.join(aliases)}")
        print(f"  \033[92m[+]\033[0m Addresses : {', '.join(addresses)}")
    except socket.herror:
        print(f"  [-] No reverse DNS record for {ip}")
    if not ip.replace('.','').isdigit():
        try:
            resolved = socket.gethostbyname(ip)
            print(f"  \033[92m[+]\033[0m Forward   : {ip} => {resolved}")
        except socket.gaierror:
            print(f"  [-] Could not resolve: {ip}")
    print()
