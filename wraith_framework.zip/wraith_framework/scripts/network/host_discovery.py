import socket
import threading
import queue
import struct
import time
import ipaddress

NAME        = "Host Discovery"
DESCRIPTION = "Sweep a subnet to find live hosts via TCP ping and optional ICMP"
AUTHOR      = "Wraith"
VERSION     = "2.0"
NOTES       = "Supports CIDR (192.168.1.0/24) or range (192.168.1.1-254)"

OPTIONS = {
    "IP":      {"description": "CIDR or range e.g. 192.168.1.0/24", "required": True,  "default": None},
    "THREADS": {"description": "Concurrent threads",                 "required": False, "default": "50"},
    "TIMEOUT": {"description": "Timeout per host (seconds)",         "required": False, "default": "1"},
    "PORTS":   {"description": "TCP ports to probe per host",        "required": False, "default": "22,80,443,445,3389"},
}

def parse_targets(s):
    hosts = []
    s = s.strip()
    try:
        net = ipaddress.ip_network(s, strict=False)
        return [str(h) for h in net.hosts()]
    except ValueError:
        pass
    if "-" in s:
        parts = s.rsplit("-", 1)
        try:
            prefix = parts[0].rsplit(".", 1)[0]
            start  = int(parts[0].rsplit(".", 1)[1])
            end    = int(parts[1])
            return [f"{prefix}.{i}" for i in range(start, end + 1)]
        except (ValueError, IndexError):
            pass
    return [s]

def tcp_ping(ip, ports, timeout):
    for port in ports:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            if s.connect_ex((ip, port)) == 0:
                s.close()
                return port
            s.close()
        except Exception:
            pass
    return None

def worker(q, results, lock, ports, timeout):
    while True:
        try:
            ip = q.get_nowait()
        except queue.Empty:
            break
        try:
            port = tcp_ping(ip, ports, timeout)
            if port:
                try:
                    hostname = socket.gethostbyaddr(ip)[0]
                except Exception:
                    hostname = ""
                with lock:
                    results.append((ip, port, hostname))
        except Exception:
            pass
        finally:
            q.task_done()

def run(opts):
    target   = opts.get("IP")
    threads  = int(opts.get("THREADS") or 50)
    timeout  = float(opts.get("TIMEOUT") or 1)
    port_str = opts.get("PORTS") or "22,80,443,445,3389"
    ports    = [int(p.strip()) for p in port_str.split(",") if p.strip().isdigit()]

    targets = parse_targets(target)
    print(f"  \033[96m[*]\033[0m Scanning {len(targets)} host(s) | threads={threads} timeout={timeout}s")
    print(f"  \033[96m[*]\033[0m Probing ports: {port_str}\n")

    q       = queue.Queue()
    results = []
    lock    = threading.Lock()
    for h in targets:
        q.put(h)

    workers = [threading.Thread(target=worker, args=(q, results, lock, ports, timeout), daemon=True) for _ in range(min(threads, len(targets)))]
    for w in workers: w.start()

    total = len(targets)
    while not q.empty():
        print(f"  \033[2m  {total - q.qsize()}/{total}\033[0m", end="\r")
        time.sleep(0.15)
    for w in workers: w.join()
    print(" " * 40, end="\r")

    results.sort(key=lambda x: [int(o) for o in x[0].split(".")] if x[0].replace(".","").isdigit() else [0]*4)

    if not results:
        print(f"  \033[91m[-]\033[0m No live hosts found")
        return

    print(f"  \033[92m[+]\033[0m {len(results)} live host(s):\n")
    print(f"  \033[2m  {'IP':<18} {'PORT':<8} HOSTNAME\033[0m")
    print(f"  \033[2m  {'-'*18} {'-'*8} {'-'*35}\033[0m")
    for ip, port, hostname in results:
        print(f"  \033[92m  {ip:<18}\033[0m \033[93m{port:<8}\033[0m \033[2m{hostname}\033[0m")
    print()
