import socket
import ssl
import datetime
import hashlib
import struct

NAME        = "SSL/TLS Auditor"
DESCRIPTION = "Audits SSL/TLS configuration: cert details, expiry, weak ciphers, protocol versions"
AUTHOR      = "Wraith"
VERSION     = "2.0"
NOTES       = "Tests for SSLv2/v3, weak ciphers, self-signed certs, and expiry issues."

OPTIONS = {
    "IP":      {"description": "Target IP or hostname", "required": True,  "default": None},
    "PORT":    {"description": "Target port",           "required": False, "default": "443"},
    "TIMEOUT": {"description": "Connection timeout (s)","required": False, "default": "5"},
}

def test_protocol(ip, port, protocol, timeout):
    try:
        ctx = ssl.SSLContext(protocol)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with ctx.wrap_socket(socket.create_connection((ip, port), timeout=timeout), server_hostname=ip) as s:
            return True, s.version(), s.cipher()
    except ssl.SSLError:
        return False, None, None
    except Exception:
        return False, None, None

def get_cert_details(ip, port, timeout):
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with ctx.wrap_socket(socket.create_connection((ip, port), timeout=timeout), server_hostname=ip) as s:
            cert_bin = s.getpeercert(binary_form=True)
            cert     = s.getpeercert()
            cipher   = s.cipher()
            version  = s.version()
            # fingerprint
            fp = hashlib.sha256(cert_bin).hexdigest()
            fp_formatted = ":".join(fp[i:i+2] for i in range(0, 16, 2)).upper()
            return cert, cipher, version, fp_formatted
    except Exception as e:
        return None, None, None, None

def run(opts):
    ip      = opts.get("IP")
    port    = int(opts.get("PORT") or 443)
    timeout = float(opts.get("TIMEOUT") or 5)

    print(f"  \033[96m[*]\033[0m Auditing SSL/TLS on {ip}:{port}...\n")

    # test port open
    try:
        s = socket.socket()
        s.settimeout(timeout)
        s.connect_ex((ip, port))
        s.close()
    except Exception as e:
        print(f"  \033[91m[-]\033[0m Cannot connect: {e}")
        return

    # ── Certificate ───────────────────────────────────────
    cert, cipher, version, fingerprint = get_cert_details(ip, port, timeout)

    print(f"  \033[93m[Certificate]\033[0m")
    if cert:
        subject = dict(x[0] for x in cert.get("subject", []))
        issuer  = dict(x[0] for x in cert.get("issuer", []))
        cn      = subject.get("commonName", "N/A")
        org     = subject.get("organizationName", "N/A")
        iss_org = issuer.get("organizationName", "N/A")
        iss_cn  = issuer.get("commonName", "N/A")
        expires_str = cert.get("notAfter", "")
        issued_str  = cert.get("notBefore", "")

        print(f"  \033[92m  [+]\033[0m Subject CN     : {cn}")
        print(f"  \033[92m  [+]\033[0m Subject Org    : {org}")
        print(f"  \033[92m  [+]\033[0m Issuer         : {iss_org} ({iss_cn})")
        print(f"  \033[92m  [+]\033[0m Valid From     : {issued_str}")
        print(f"  \033[92m  [+]\033[0m Valid Until    : {expires_str}")
        print(f"  \033[92m  [+]\033[0m SHA-256 (short): {fingerprint}")

        # check self-signed
        if subject == issuer:
            print(f"  \033[91m  [!]\033[0m SELF-SIGNED CERTIFICATE")

        # check expiry
        try:
            exp = datetime.datetime.strptime(expires_str, "%b %d %H:%M:%S %Y %Z")
            now = datetime.datetime.utcnow()
            days_left = (exp - now).days
            if days_left < 0:
                print(f"  \033[91m  [!]\033[0m CERTIFICATE EXPIRED {abs(days_left)} days ago!")
            elif days_left < 30:
                print(f"  \033[93m  [!]\033[0m Certificate expires in {days_left} days — renew soon")
            else:
                print(f"  \033[92m  [+]\033[0m Expires in {days_left} days")
        except Exception:
            pass

        # SANs
        sans = [v for t,v in cert.get("subjectAltName", []) if t == "DNS"]
        if sans:
            print(f"  \033[92m  [+]\033[0m SANs ({len(sans)})          : {', '.join(sans[:8])}")
            if len(sans) > 8:
                print(f"  \033[2m            ... and {len(sans)-8} more\033[0m")
    else:
        print(f"  \033[91m  [-]\033[0m Could not retrieve certificate")
    print()

    # ── Active Protocol + Cipher ──────────────────────────
    print(f"  \033[93m[Active Connection]\033[0m")
    if version:
        ver_color = "\033[91m" if version in ("SSLv2", "SSLv3", "TLSv1", "TLSv1.1") else "\033[92m"
        print(f"  {ver_color}  [+]\033[0m Protocol : {version}")
    if cipher:
        cipher_str = f"{cipher[0]} ({cipher[1]} {cipher[2]} bits)"
        weak = cipher[2] and int(cipher[2]) < 128
        c_color = "\033[91m" if weak else "\033[92m"
        print(f"  {c_color}  [+]\033[0m Cipher   : {cipher_str}")
    print()

    # ── Protocol Version Tests ────────────────────────────
    print(f"  \033[93m[Protocol Support]\033[0m")
    findings = []
    proto_tests = []

    # Test TLS versions via string-based method
    for proto_str in ["TLSv1", "TLSv1.1", "TLSv1.2", "TLSv1.3"]:
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            # set min/max version
            ver_map = {
                "TLSv1":   (ssl.TLSVersion.TLSv1,   ssl.TLSVersion.TLSv1),
                "TLSv1.1": (ssl.TLSVersion.TLSv1_1, ssl.TLSVersion.TLSv1_1),
                "TLSv1.2": (ssl.TLSVersion.TLSv1_2, ssl.TLSVersion.TLSv1_2),
                "TLSv1.3": (ssl.TLSVersion.TLSv1_3, ssl.TLSVersion.TLSv1_3),
            }
            if proto_str in ver_map:
                try:
                    ctx.minimum_version, ctx.maximum_version = ver_map[proto_str]
                    with ctx.wrap_socket(socket.create_connection((ip, port), timeout=timeout), server_hostname=ip):
                        supported = True
                except Exception:
                    supported = False
                weak = proto_str in ("TLSv1", "TLSv1.1")
                color = "\033[91m" if weak else "\033[92m"
                status_str = "\033[92msupported\033[0m" if supported else "\033[2mnot supported\033[0m"
                warn = f"  \033[91m← WEAK\033[0m" if (weak and supported) else ""
                print(f"    {color}{'[+]' if supported else '[-]'}\033[0m {proto_str:<12} {status_str}{warn}")
                if weak and supported:
                    findings.append(f"{proto_str} is enabled — vulnerable to POODLE/BEAST")
        except AttributeError:
            pass

    print()

    # ── Findings Summary ─────────────────────────────────
    if findings:
        print(f"  \033[91m[Findings]\033[0m")
        for f in findings:
            print(f"  \033[91m  [!]\033[0m {f}")
        print()
    else:
        print(f"  \033[92m[+]\033[0m No critical SSL issues detected")
        print()
