import socket
import threading
import queue
import time
import ssl

NAME        = "HTTP Directory Bruteforcer"
DESCRIPTION = "Threaded directory and file discovery against web servers"
AUTHOR      = "Wraith"
VERSION     = "2.0"
NOTES       = "Uses raw sockets for speed. Detects redirects, auth-required, and error pages."

OPTIONS = {
    "IP":        {"description": "Target IP or hostname",               "required": True,  "default": None},
    "PORT":      {"description": "Target port",                         "required": False, "default": "80"},
    "WORDLIST":  {"description": "Path to directory/file wordlist",     "required": True,  "default": None},
    "THREADS":   {"description": "Concurrent threads",                  "required": False, "default": "20"},
    "TIMEOUT":   {"description": "Request timeout (s)",                 "required": False, "default": "5"},
    "SSL":       {"description": "Use HTTPS",                           "required": False, "default": "false"},
    "EXT":       {"description": "File extensions to try (php,html)",   "required": False, "default": ""},
    "CODE":      {"description": "Status codes to report (200,301,302)","required": False, "default": "200,301,302,401,403"},
}

STATUS_COLORS = {
    "200": "\033[92m",  # green
    "301": "\033[93m",  # yellow
    "302": "\033[93m",  # yellow
    "401": "\033[95m",  # magenta — auth required (interesting)
    "403": "\033[94m",  # blue — forbidden (exists but blocked)
}

def http_request(ip, port, path, timeout, use_ssl):
    try:
        raw = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        raw.settimeout(timeout)
        raw.connect((ip, port))
        if use_ssl:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            s = ctx.wrap_socket(raw, server_hostname=ip)
        else:
            s = raw
        req = f"GET {path} HTTP/1.1\r\nHost: {ip}\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n"
        s.send(req.encode())
        response = b""
        while True:
            chunk = s.recv(4096)
            if not chunk: break
            response += chunk
            if len(response) > 8192: break
        s.close()
        decoded = response.decode(errors="ignore")
        status = decoded.split(" ", 2)[1] if " " in decoded else "0"
        # get content-length or actual length
        length = 0
        for line in decoded.splitlines():
            if line.lower().startswith("content-length:"):
                try: length = int(line.split(":", 1)[1].strip())
                except: pass
        location = ""
        for line in decoded.splitlines():
            if line.lower().startswith("location:"):
                location = line.split(":", 1)[1].strip()
        return status.strip(), length, location
    except Exception:
        return None, 0, ""

def worker(ip, port, path_queue, results, lock, timeout, use_ssl, want_codes, tried):
    while True:
        try:
            path = path_queue.get_nowait()
        except queue.Empty:
            break
        try:
            with lock:
                tried[0] += 1
            status, length, location = http_request(ip, port, path, timeout, use_ssl)
            if status and status in want_codes:
                with lock:
                    results.append((status, path, length, location))
        except Exception:
            pass
        finally:
            path_queue.task_done()

def run(opts):
    ip       = opts.get("IP")
    port     = int(opts.get("PORT") or 80)
    wordlist = opts.get("WORDLIST")
    threads  = int(opts.get("THREADS") or 20)
    timeout  = float(opts.get("TIMEOUT") or 5)
    use_ssl  = (opts.get("SSL") or "false").lower() in ("true", "1", "yes")
    ext_str  = opts.get("EXT") or ""
    code_str = opts.get("CODE") or "200,301,302,401,403"
    want_codes = set(c.strip() for c in code_str.split(","))

    exts = [""] + [f".{e.strip().lstrip('.')}" for e in ext_str.split(",") if e.strip()]

    try:
        with open(wordlist) as f:
            words = [l.strip().lstrip("/") for l in f if l.strip() and not l.startswith("#")]
    except Exception as e:
        print(f"  \033[91m[-]\033[0m Cannot read wordlist: {e}")
        return

    paths = []
    for word in words:
        for ext in exts:
            paths.append(f"/{word}{ext}")

    protocol = "https" if use_ssl else "http"
    print(f"  \033[96m[*]\033[0m Target  : {protocol}://{ip}:{port}")
    print(f"  \033[96m[*]\033[0m Paths   : {len(paths)}  Threads: {threads}  Timeout: {timeout}s")
    print(f"  \033[96m[*]\033[0m Codes   : {code_str}")
    if ext_str:
        print(f"  \033[96m[*]\033[0m Exts    : {ext_str}")
    print()

    pq      = queue.Queue()
    results = []
    lock    = threading.Lock()
    tried   = [0]

    for p in paths:
        pq.put(p)

    workers = [threading.Thread(target=worker, args=(ip, port, pq, results, lock, timeout, use_ssl, want_codes, tried), daemon=True)
               for _ in range(min(threads, len(paths)))]
    for w in workers: w.start()

    total = len(paths)
    while not pq.empty():
        done = tried[0]
        print(f"  \033[2m  {done}/{total} | Found: {len(results)}\033[0m", end="\r")
        time.sleep(0.2)

    for w in workers: w.join()
    print(" " * 60, end="\r")

    if not results:
        print(f"  \033[91m[-]\033[0m No paths found")
        return

    results.sort(key=lambda x: x[1])
    print(f"  \033[92m[+]\033[0m {len(results)} path(s) found:\n")
    print(f"  \033[2m  {'STATUS':<8} {'LENGTH':<10} PATH\033[0m")
    print(f"  \033[2m  {'─'*8} {'─'*10} {'─'*45}\033[0m")
    for status, path, length, location in results:
        color = STATUS_COLORS.get(status, "\033[0m")
        loc   = f"  -> {location}" if location else ""
        print(f"  {color}  {status:<8}\033[0m \033[2m{str(length)+'B':<10}\033[0m {path}{loc}")
    print()
