import socket
import ssl
import re

NAME        = "HTTP Web Recon"
DESCRIPTION = "Full web fingerprint: headers, cookies, forms, comments, links, and tech stack"
AUTHOR      = "Wraith"
VERSION     = "2.0"
NOTES       = "Grabs index page and parses for intelligence without external dependencies."

OPTIONS = {
    "IP":      {"description": "Target IP or hostname",     "required": True,  "default": None},
    "PORT":    {"description": "Target port",               "required": False, "default": "80"},
    "PATH":    {"description": "URL path to request",       "required": False, "default": "/"},
    "SSL":     {"description": "Use HTTPS",                 "required": False, "default": "false"},
    "TIMEOUT": {"description": "Connection timeout (s)",    "required": False, "default": "8"},
}

def make_request(ip, port, path, use_ssl, timeout):
    raw = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    raw.settimeout(timeout)
    raw.connect((ip, port))
    if use_ssl:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        s = ctx.wrap_socket(raw, server_hostname=ip)
    else:
        s = raw
    req = f"GET {path} HTTP/1.1\r\nHost: {ip}\r\nUser-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\nAccept: text/html,application/xhtml+xml\r\nConnection: close\r\n\r\n"
    s.send(req.encode())
    data = b""
    while True:
        chunk = s.recv(8192)
        if not chunk: break
        data += chunk
        if len(data) > 200000: break
    s.close()
    decoded = data.decode(errors="ignore")
    # split headers and body
    if "\r\n\r\n" in decoded:
        header_part, body = decoded.split("\r\n\r\n", 1)
    else:
        header_part, body = decoded, ""
    return header_part, body

def parse_headers(header_str):
    headers = {}
    lines = header_str.splitlines()
    status = lines[0] if lines else ""
    for line in lines[1:]:
        if ": " in line:
            k, v = line.split(": ", 1)
            headers[k.lower().strip()] = v.strip()
    return status, headers

def run(opts):
    ip      = opts.get("IP")
    port    = int(opts.get("PORT") or 80)
    path    = opts.get("PATH") or "/"
    use_ssl = (opts.get("SSL") or "false").lower() in ("true", "1", "yes")
    timeout = float(opts.get("TIMEOUT") or 8)
    proto   = "https" if use_ssl else "http"

    print(f"  \033[96m[*]\033[0m Requesting {proto}://{ip}:{port}{path}\n")

    try:
        header_str, body = make_request(ip, port, path, use_ssl, timeout)
    except Exception as e:
        print(f"  \033[91m[-]\033[0m Connection failed: {e}")
        return

    status, headers = parse_headers(header_str)

    # ── Status ──────────────────────────────────────────
    print(f"  \033[93m[Response]\033[0m")
    color = "\033[92m" if "200" in status else "\033[93m" if "30" in status else "\033[91m"
    print(f"  {color}  {status}\033[0m")
    print()

    # ── Headers ─────────────────────────────────────────
    print(f"  \033[93m[Headers]\033[0m")
    interesting = {
        "server": "Server",
        "x-powered-by": "X-Powered-By",
        "x-aspnet-version": "ASP.NET Ver",
        "x-aspnetmvc-version": "ASP.NET MVC",
        "x-generator": "Generator",
        "x-frame-options": "X-Frame-Options",
        "strict-transport-security": "HSTS",
        "content-security-policy": "CSP",
        "x-content-type-options": "X-Content-Type",
        "set-cookie": "Cookie",
        "via": "Via",
        "location": "Location",
    }
    for key, label in interesting.items():
        if key in headers:
            marker = "\033[92m[+]\033[0m" if key in ("server","x-powered-by","x-aspnet-version","x-generator") else "\033[2m[ ]\033[0m"
            val = headers[key][:100]
            print(f"    {marker} {label:<22} {val}")
    print()

    # ── SSL Cert ────────────────────────────────────────
    if use_ssl:
        print(f"  \033[93m[SSL]\033[0m")
        try:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with ctx.wrap_socket(socket.socket(), server_hostname=ip) as s:
                s.settimeout(timeout)
                s.connect((ip, port))
                cert = s.getpeercert()
                subj = dict(x[0] for x in cert.get("subject", []))
                print(f"    \033[92m[+]\033[0m CN: {subj.get('commonName','N/A')}  Expires: {cert.get('notAfter','N/A')}")
                sans = [v for t,v in cert.get("subjectAltName",[]) if t=="DNS"]
                if sans: print(f"    \033[92m[+]\033[0m SANs: {', '.join(sans[:6])}")
        except Exception as e:
            print(f"    \033[91m[-]\033[0m {e}")
        print()

    if not body:
        print(f"  \033[2m  (empty body)\033[0m")
        return

    # ── Tech Stack Detection ─────────────────────────────
    tech_signatures = {
        "WordPress":      [r"wp-content", r"wp-includes", r"/wp-json/"],
        "Joomla":         [r"/components/com_", r"Joomla!"],
        "Drupal":         [r"Drupal", r"/sites/default/"],
        "Laravel":        [r"laravel_session", r"XSRF-TOKEN"],
        "Django":         [r"csrfmiddlewaretoken", r"django"],
        "React":          [r"__reactFiber", r"react.production"],
        "Angular":        [r"ng-version", r"angular"],
        "Vue.js":         [r"__vue__", r"vue.min.js"],
        "jQuery":         [r"jquery", r"jQuery"],
        "Bootstrap":      [r"bootstrap.min.css", r"bootstrap.min.js"],
        "PHP":            [r"\.php", r"PHPSESSID"],
        "ASP.NET":        [r"__VIEWSTATE", r"aspnetForm"],
        "Nginx":          [r"nginx"],
        "Apache":         [r"Apache"],
        "IIS":            [r"Microsoft-IIS"],
        "Elasticsearch":  [r'"cluster_name"', r'"version".*"number"'],
    }
    found_tech = []
    search = (header_str + body).lower()
    for tech, patterns in tech_signatures.items():
        for pat in patterns:
            if re.search(pat, search, re.IGNORECASE):
                found_tech.append(tech)
                break

    if found_tech:
        print(f"  \033[93m[Tech Stack]\033[0m")
        for t in found_tech:
            print(f"  \033[92m  [+]\033[0m {t}")
        print()

    # ── Comments ────────────────────────────────────────
    comments = re.findall(r"<!--(.*?)-->", body, re.DOTALL)
    interesting_comments = [c.strip() for c in comments if len(c.strip()) > 10 and not c.strip().startswith("[if")]
    if interesting_comments:
        print(f"  \033[93m[HTML Comments ({len(interesting_comments)})]\033[0m")
        for c in interesting_comments[:5]:
            c_clean = " ".join(c.split())[:120]
            print(f"  \033[93m  [!]\033[0m {c_clean}")
        print()

    # ── Forms ────────────────────────────────────────────
    forms = re.findall(r"<form[^>]*>(.*?)</form>", body, re.DOTALL | re.IGNORECASE)
    if forms:
        print(f"  \033[93m[Forms ({len(forms)})]\033[0m")
        for i, form in enumerate(forms[:5]):
            action = re.search(r'action=["\']([^"\']*)["\']', form, re.IGNORECASE)
            method = re.search(r'method=["\']([^"\']*)["\']', form, re.IGNORECASE)
            inputs = re.findall(r'<input[^>]*name=["\']([^"\']*)["\']', form, re.IGNORECASE)
            a = action.group(1) if action else "(none)"
            m = method.group(1).upper() if method else "GET"
            print(f"  \033[92m  [+]\033[0m Form {i+1}: {m} {a}  inputs={inputs}")
        print()

    # ── Interesting paths / links ─────────────────────────
    paths_found = re.findall(r'(?:href|src|action)=["\']([^"\']+)["\']', body, re.IGNORECASE)
    interesting_paths = set()
    for p in paths_found:
        p = p.strip()
        if p.startswith(("http://", "https://", "//", "mailto:", "#", "javascript:")):
            continue
        if any(x in p.lower() for x in ["admin", "login", "upload", "api", "backup", "config", "debug", ".git", ".env", "secret"]):
            interesting_paths.add(p)

    if interesting_paths:
        print(f"  \033[93m[Interesting Paths]\033[0m")
        for p in sorted(interesting_paths)[:15]:
            print(f"  \033[93m  [!]\033[0m {p}")
        print()

    # ── robots.txt hint ──────────────────────────────────
    print(f"  \033[96m[*]\033[0m Tip: try fetching /robots.txt and /sitemap.xml for more paths")
    print()
