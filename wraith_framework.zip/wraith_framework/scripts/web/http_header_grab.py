import socket

NAME        = "HTTP Header Grabber"
DESCRIPTION = "Fingerprints a web server via HTTP response headers"
AUTHOR      = "You"
VERSION     = "1.0"

OPTIONS = {
    "IP":      {"description": "Target IP or hostname",  "required": True,  "default": None},
    "PORT":    {"description": "Target port",            "required": False, "default": "80"},
    "TIMEOUT": {"description": "Connection timeout (s)", "required": False, "default": "5"},
}

INTERESTING = ["server", "x-powered-by", "set-cookie", "x-aspnet", "via", "x-generator", "x-frame"]

def run(opts):
    ip      = opts.get("IP")
    port    = int(opts.get("PORT") or 80)
    timeout = float(opts.get("TIMEOUT") or 5)
    print(f"  Grabbing HTTP headers from {ip}:{port}...\n")
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((ip, port))
        s.send(f"HEAD / HTTP/1.1\r\nHost: {ip}\r\nConnection: close\r\n\r\n".encode())
        resp = b""
        while True:
            chunk = s.recv(4096)
            if not chunk: break
            resp += chunk
        s.close()
        for line in resp.decode(errors="ignore").split("\r\n"):
            if not line.strip(): continue
            if any(h in line.lower() for h in INTERESTING):
                print(f"  \033[92m[+]\033[0m {line}")
            else:
                print(f"  \033[2m[ ] {line}\033[0m")
    except ConnectionRefusedError:
        print(f"  [-] Connection refused.")
    except socket.timeout:
        print("  [-] Timed out.")
    except Exception as e:
        print(f"  [!] {e}")
    print()
